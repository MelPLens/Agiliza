/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objetos;

import java.util.InputMismatchException;

/**
 *
 * @author vinic
 */
public class Funcionario {
     
    private String senha;
    private String nome;
    private String telefone;
    private String endereco;
    private String cidade;
    private String cpf;
    private String email;
    private String sexo;
    private String estado;
    private String funcao;
    
    public Funcionario(){
        
        this.nome = "";
        this.endereco = "";
        this.telefone = "";
        this.cidade = "";
        this.senha = "";
        this.cpf = "";
        this.email = "";
        this.sexo = "";
        this.estado = "";
        this.funcao = "";
    }
    
    public Funcionario(String nome,String senha,String telefone, String cidade, String endereco, String cpf,String email,String sexo,String estado,String funcao){
        
        this.nome = nome;
        this.senha = senha;
        this.telefone = telefone;
        this.cidade = cidade;
        this.endereco = endereco;
        this.cpf = cpf;
        this.email = email;
        this.sexo = sexo;
        this.estado = estado;
        this.funcao = funcao;
    }

    /**
     * @return the cliente
     */
    

    /**
     * @param cliente the cliente to set
     */
   
   

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * @return the cidade
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * @param cidade the cidade to set
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the sexo
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * @param sexo the sexo to set
     */
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
     public boolean ValidarCPF(){
        // considera-se erro CPF's formados por uma sequencia de numeros iguais
        if (this.cpf.equals("00000000000") ||
            this.cpf.equals("11111111111") ||
            this.cpf.equals("22222222222") || this.cpf.equals("33333333333") ||
            this.cpf.equals("44444444444") || this.cpf.equals("55555555555") ||
            this.cpf.equals("66666666666") || this.cpf.equals("77777777777") ||
            this.cpf.equals("88888888888") || this.cpf.equals("99999999999") ||
            (this.cpf.length() != 11))
            return(false);

        char dig10, dig11;
        int sm, i, r, num, peso;

        // "try" - protege o codigo para eventuais erros de conversao de tipo (int)
        try {
        // Calculo do 1o. Digito Verificador
            sm = 0;
            peso = 10;
            for (i=0; i<9; i++) {
        // converte o i-esimo caractere do CPF em um numero:
        // por exemplo, transforma o caractere '0' no inteiro 0
        // (48 eh a posicao de '0' na tabela ASCII)
            num = (int)(this.cpf.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
            }

            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11))
                dig10 = '0';
            else dig10 = (char)(r + 48); // converte no respectivo caractere numerico

        // Calculo do 2o. Digito Verificador
            sm = 0;
            peso = 11;
            for(i=0; i<10; i++) {
            num = (int)(this.cpf.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
            }

            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11))
                 dig11 = '0';
            else dig11 = (char)(r + 48);

        // Verifica se os digitos calculados conferem com os digitos informados.
            if ((dig10 == this.cpf.charAt(9)) && (dig11 == this.cpf.charAt(10)))
                 return(true);
            else return(false);
                } catch (InputMismatchException erro) {
                return(false);
            }
    }

    /**
     * @return the funcao
     */
    public String getFuncao() {
        return funcao;
    }

    /**
     * @param funcao the funcao to set
     */
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
    
    
    
    
}
