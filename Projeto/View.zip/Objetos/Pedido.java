
package Objetos;


public class Pedido {
    
    private String idPedido;
    private String  codigo;
    private String nome;
    private String qtde;
    private String cliente;
    private String os;
    private String dataEntrega;

    public Pedido() {
    }

    public Pedido(String idPedido, String codigo, String nome, String qtde, String cliente, String os, String dataEntrega) {
        this.idPedido = idPedido;
        this.codigo = codigo;
        this.nome = nome;
        this.qtde = qtde;
        this.cliente = cliente;
        this.os = os;
        this.dataEntrega = dataEntrega;
    }

    public String getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(String idPedido) {
        this.idPedido = idPedido;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getQtde() {
        return qtde;
    }

    public void setQtde(String qtde) {
        this.qtde = qtde;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(String dataEntrega) {
        this.dataEntrega = dataEntrega;
    }
    
    
    
}
