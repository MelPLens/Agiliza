
package Objetos;

public class Produto {
    
    private String Codigo;
    private String Cliente;
    private String fornecedor;
    private String preco_custo;
    private String preco_venda;
    private String icms;
    private String nome;
    private String status;

    public Produto() {
    }

    public Produto(String nome, String Codigo, String Cliente, String fornecedor, String preco_custo, String preco_venda, String icms, String status) {
       
        this.Codigo = Codigo;
        this.Cliente = Cliente;
        this.fornecedor = fornecedor;
        this.preco_custo = preco_custo;
        this.preco_venda = preco_venda;
        this.icms = icms;
        this.nome = nome;
        this.status = status;
    }


    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String Cliente) {
        this.Cliente = Cliente;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public String getPreco_custo() {
        return preco_custo;
    }

    public void setPreco_custo(String preco_custo) {
        this.preco_custo = preco_custo;
    }

    public String getPreco_venda() {
        return preco_venda;
    }

    public void setPreco_venda(String preco_venda) {
        this.preco_venda = preco_venda;
    }

    public String getIcms() {
        return icms;
    }

    public void setIcms(String icms) {
        this.icms = icms;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    

}