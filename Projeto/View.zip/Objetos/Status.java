
package Objetos;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import Conexoes.MySQL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class Status {
    
    private String codigo;
    private String nome;
    private String qtdeInicio;
    private String qtdeTermino;
    private String dataInicio;
    private String dataTermino;
    private String horarioInicio;
    private String horarioTermino;
    private String status;
    
     private Connection conn;

   
        
   
    MySQL conectar = new MySQL();

    public Status() {
        //conn = new ConnectionFactory().getConnection();
    }

    public Status(String codigo, String nome, String qtdeInicio,String qtdeTermino, String dataInicio, String dataTermino, String horarioInicio, String horarioTermino, String status) {
        this.codigo = codigo;
        this.nome = nome;
        this.qtdeInicio = qtdeInicio;
        this.qtdeTermino = qtdeTermino;
        this.dataInicio = dataInicio;
        this.dataTermino = dataTermino;
        this.horarioInicio = horarioInicio;
        this.horarioTermino = horarioTermino;
        this.status = status;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getQtdeInicio() {
        return qtdeInicio;
    }

    public void setQtdeInicio(String qtdeInicio) {
        this.qtdeInicio = qtdeInicio;
    }

    public String getQtdeTermino() {
        return qtdeTermino;
    }

    public void setQtdeTermino(String qtdeTermino) {
        this.qtdeTermino = qtdeTermino;
    }

    public String getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(String dataInicio) {
        this.dataInicio = dataInicio;
    }

    public String getDataTermino() {
        return dataTermino;
    }

    public void setDataTermino(String dataTermino) {
        this.dataTermino = dataTermino;
    }

    public String getHorarioInicio() {
        return horarioInicio;
    }

    public void setHorarioInicio(String horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public String getHorarioTermino() {
        return horarioTermino;
    }

    public void setHorarioTermino(String horarioTermino) {
        this.horarioTermino = horarioTermino;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }

    public MySQL getConectar() {
        return conectar;
    }

    public void setConectar(MySQL conectar) {
        this.conectar = conectar;
    }
    
    public ArrayList<Status> consultar(String codigo) {
        
        ArrayList<Status> lista = new ArrayList<>();
       
        String sql = "select * from statusatual where codigo like ?";
        PreparedStatement comando;
        ResultSet resultado;
        try {
            
            this.conectar.conectaBanco() ;
            comando = conn.prepareStatement(sql);
            comando.setString(1, codigo);
            resultado = comando.executeQuery();
            while (resultado.next()) {
                
                Status st = new Status();
                st.setCodigo(resultado.getString("codigo"));
                st.setNome(resultado.getString("nome"));
                st.setQtdeInicio(resultado.getString("qtdeInicio"));
                st.setDataInicio(resultado.getString("dataInicio"));
                st.setDataTermino(resultado.getString("dataTermino"));
                st.setHorarioInicio(resultado.getString("horarioInicio"));
                st.setHorarioTermino(resultado.getString("horarioTermino"));
                st.setStatus(resultado.getString("status"));
                st.setQtdeTermino(resultado.getString("qtdeTermino"));
            
            }
            return lista;

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    

    
}
