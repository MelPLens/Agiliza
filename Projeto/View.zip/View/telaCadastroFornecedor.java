
package View;


import Conexoes.MySQL;
import Objetos.Fornecedor;
import javax.swing.JOptionPane;



public class telaCadastroFornecedor extends javax.swing.JFrame {
            MySQL conectar = new MySQL();
            Fornecedor novoFornecedor = new Fornecedor();


    public telaCadastroFornecedor() {
        initComponents();
    }
    private void cadastraFornecedor(Fornecedor novoFornecedor){
        this.conectar.conectaBanco();
        novoFornecedor.setIdFornecedor(txtIdFornecedor.getText());
        novoFornecedor.setNome(txtNomeFornecedor.getText());
        novoFornecedor.setCnpj(txtCnpjFornecedor.getText()); 
        novoFornecedor.setRamo(txtRamoFornecedor.getText());
        novoFornecedor.setTelefone(txtTelefoneFornecedor.getText());        
        novoFornecedor.setEmail(txtEmailFornecedor.getText());
       
        
        
        try{
            this.conectar.insertSQL("INSERT INTO fornecedor("
                    + "idfornecedor,"
                    + "nome,"
                    + "cnpj,"
                    + "ramo,"
                    + "telefone,"
                    + "email)"
                    + " VALUES(" 
                    + "'" + novoFornecedor.getIdFornecedor()+ "',"
                    + "'" + novoFornecedor.getNome()+ "'," 
                    + "'" + novoFornecedor.getCnpj()+ "',"
                    + "'" + novoFornecedor.getRamo()+ "',"
                    + "'" + novoFornecedor.getTelefone()+ "',"
                    + "'" + novoFornecedor.getEmail()+ "');"
                    
                              
         );
                  
        
        }catch(Exception e){
        
            System.out.println("Erro ao cadastrar fornecedor " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar fornecedor");
        
    }finally{
        this.conectar.fechaBanco();
        JOptionPane.showMessageDialog(null,"Cadastro feito");

    }
  } 
    private void buscarFornecedor(Fornecedor novoFornecedor){
         
        this.conectar.conectaBanco();
        
        String consultaFornecedor = this.txtNomeFornecedor.getText();
                
        try {
            this.conectar.executarSQL(
                   "SELECT "
                    + "idFornecedor,"
                    + "nome,"
                    + "cnpj,"
                    + "ramo,"
                    + "telefone,"
                    + "email "
                 + " FROM"
                     + " fornecedor"
                 + " WHERE"
                     + " nome = '" + consultaFornecedor + "'"
                + ";"
            );
            
            while(this.conectar.getResultSet().next()){               
                novoFornecedor.setIdFornecedor(this.conectar.getResultSet().getString(1));
                novoFornecedor.setNome(this.conectar.getResultSet().getString(2));
                novoFornecedor.setCnpj(this.conectar.getResultSet().getString(3));
                novoFornecedor.setRamo(this.conectar.getResultSet().getString(4));
                novoFornecedor.setTelefone(this.conectar.getResultSet().getString(5));
                novoFornecedor.setEmail(this.conectar.getResultSet().getString(6));
                
                
           }
            
           if(novoFornecedor.getCnpj()== ""){
                JOptionPane.showMessageDialog(null, "Fornecedor não encontrado!");
           }
           
        } catch (Exception e) {            
            System.out.println("Erro ao consultar fornecedor " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar fornecedor");
            
        }finally{
            txtIdFornecedor.setText(novoFornecedor.getIdFornecedor());
            txtNomeFornecedor.setText(novoFornecedor.getNome());
            txtCnpjFornecedor.setText(novoFornecedor.getCnpj());
            txtRamoFornecedor.setText(novoFornecedor.getRamo());
            txtTelefoneFornecedor.setText(novoFornecedor.getTelefone());
            txtEmailFornecedor.setText(novoFornecedor.getEmail());
            

            this.conectar.fechaBanco();   
        } 
        
        
        
    }
    
    private void deletarFornecedor(Fornecedor novoFornecedor){
        this.conectar.conectaBanco();
        
        String consultacnpj = txtCnpjFornecedor.getText(); 
        
        try {            
            this.conectar.updateSQL(
                "DELETE FROM fornecedor "
                + " WHERE "
                    + "cnpj = '" + consultacnpj + "'"
                + ";"            
            );
            
        } catch (Exception e) {
            System.out.println("Erro ao deletar Fornecedor " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar Fornecedor");
        }finally{
            this.conectar.fechaBanco();
            limpaCamposCadastro();
            
         
            JOptionPane.showMessageDialog(null, "Fornecedor deletado com sucesso");            
        }   
        
        
    
     }
        public void atualizarFornecedor(Fornecedor novoFornecedor){
        this.conectar.conectaBanco();
        
        String consultanome = this.txtNomeFornecedor.getText();
        
        try {
            this.conectar.updateSQL(
                "UPDATE fornecedor SET "                    
                    + "idfornecedor = '" + txtNomeFornecedor.getText() + "',"                    
                    + "nome = '" + txtCnpjFornecedor.getText() + "',"
                    + "cnpj = '" + txtRamoFornecedor.getText() +"',"
                    + "telefone = '" + txtTelefoneFornecedor.getText() + "',"
                    + "email = '" + txtEmailFornecedor.getText() + "'"                 
                    + " WHERE "
                    + "nome = '" + consultanome + "'"
                + ";"
            );
        }catch(Exception e){
            System.out.println("Erro ao atualizar Fornecedor " +  e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar Fornecedor");
        }finally{
            this.conectar.fechaBanco();
            limpaCamposCadastro();
            JOptionPane.showMessageDialog(null, "Fornecedor atualizado com sucesso");
        }
    }

     private void limpaCamposCadastro(){
        txtIdFornecedor.setText("");
        txtNomeFornecedor.setText("");
        txtCnpjFornecedor.setText("");
        txtRamoFornecedor.setText("");
        txtTelefoneFornecedor.setText("");
        txtEmailFornecedor.setText("");
      
      
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNomeFornecedor = new javax.swing.JTextField();
        txtEmailFornecedor = new javax.swing.JTextField();
        txtCnpjFornecedor = new javax.swing.JTextField();
        txtTelefoneFornecedor = new javax.swing.JTextField();
        txtRamoFornecedor = new javax.swing.JTextField();
        btnCadastraFornecedor = new javax.swing.JButton();
        btnBuscaFornecedor = new javax.swing.JButton();
        btnDeletaFornecedor = new javax.swing.JButton();
        btnAtualizaFornecedor = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtIdFornecedor = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nome");

        jLabel2.setText("Ramo");

        jLabel3.setText("Email");

        jLabel4.setText("CNPJ");

        jLabel5.setText("Telefone");

        txtNomeFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtNomeFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeFornecedorActionPerformed(evt);
            }
        });

        txtEmailFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtEmailFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailFornecedorActionPerformed(evt);
            }
        });

        txtCnpjFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txtTelefoneFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtTelefoneFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefoneFornecedorActionPerformed(evt);
            }
        });

        txtRamoFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnCadastraFornecedor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCadastraFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/mole.png"))); // NOI18N
        btnCadastraFornecedor.setText("CADASTRAR");
        btnCadastraFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCadastraFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastraFornecedorActionPerformed(evt);
            }
        });

        btnBuscaFornecedor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBuscaFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/binoculars.png"))); // NOI18N
        btnBuscaFornecedor.setText("BUSCAR");
        btnBuscaFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscaFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscaFornecedorActionPerformed(evt);
            }
        });

        btnDeletaFornecedor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDeletaFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/delete.png"))); // NOI18N
        btnDeletaFornecedor.setText("DELETAR");
        btnDeletaFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnDeletaFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletaFornecedorActionPerformed(evt);
            }
        });

        btnAtualizaFornecedor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAtualizaFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/updated.png"))); // NOI18N
        btnAtualizaFornecedor.setText("ATUALIZAR");
        btnAtualizaFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAtualizaFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizaFornecedorActionPerformed(evt);
            }
        });

        jLabel6.setText("ID");

        txtIdFornecedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtIdFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCnpjFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTelefoneFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNomeFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtRamoFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEmailFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(127, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnCadastraFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btnBuscaFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDeletaFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(btnAtualizaFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtIdFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNomeFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtCnpjFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(41, 41, 41)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtEmailFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtTelefoneFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtRamoFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(122, 122, 122))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAtualizaFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDeletaFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscaFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCadastraFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtEmailFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailFornecedorActionPerformed

    private void txtTelefoneFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneFornecedorActionPerformed

    private void btnAtualizaFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizaFornecedorActionPerformed
        atualizarFornecedor(novoFornecedor);
    }//GEN-LAST:event_btnAtualizaFornecedorActionPerformed

    private void btnCadastraFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastraFornecedorActionPerformed
        cadastraFornecedor(novoFornecedor);
        limpaCamposCadastro();
        
    }//GEN-LAST:event_btnCadastraFornecedorActionPerformed

    private void btnBuscaFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscaFornecedorActionPerformed
        buscarFornecedor(novoFornecedor);
    }//GEN-LAST:event_btnBuscaFornecedorActionPerformed

    private void btnDeletaFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletaFornecedorActionPerformed
       deletarFornecedor(novoFornecedor);
    }//GEN-LAST:event_btnDeletaFornecedorActionPerformed

    private void txtNomeFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeFornecedorActionPerformed

  
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(telaCadastroFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(telaCadastroFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(telaCadastroFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(telaCadastroFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new telaCadastroFornecedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizaFornecedor;
    private javax.swing.JButton btnBuscaFornecedor;
    private javax.swing.JButton btnCadastraFornecedor;
    private javax.swing.JButton btnDeletaFornecedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField txtCnpjFornecedor;
    private javax.swing.JTextField txtEmailFornecedor;
    private javax.swing.JTextField txtIdFornecedor;
    private javax.swing.JTextField txtNomeFornecedor;
    private javax.swing.JTextField txtRamoFornecedor;
    private javax.swing.JTextField txtTelefoneFornecedor;
    // End of variables declaration//GEN-END:variables
}
