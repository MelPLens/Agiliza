/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ac2_linguagemprogramação;
import View.telaCadastroFornecedor;

/**
 *
 * @author vinic
 */
public class AC2_linguagemProgramação {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        telaCadastroFornecedor tcfo = new telaCadastroFornecedor();
        
    }
    
}
